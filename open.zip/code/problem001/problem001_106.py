i=1

while i<=9:
	j=1
	while j<=9:
		print '%d%s%d%s%d'%(i,"x",j,"=",i*j)
		j=j+1
	
	i=i+1