num_a = [1, 2, 3, 4, 5, 6, 7, 8, 9]

for i in num_a:
    for j in num_a:
        print(i, 'x', j, '=', i*j, sep='')

