for a in [1,2,3,4,5,6,7,8,9]:
	for b in [1,2,3,4,5,6,7,8,9]:
		print ("{0}x{1}={2}".format(a,b,a*b))