for i in range(9):
    for j in range(9):
        print "%dx%d=%d" %(i+1,j+1, (i+1)*(j+1))