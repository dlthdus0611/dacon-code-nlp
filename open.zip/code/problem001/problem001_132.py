i=1
k=1
for k in range(1,10):
    for i in range(1,10):
        print(str(k)+"x"+str(i)+"="+str(k*i))