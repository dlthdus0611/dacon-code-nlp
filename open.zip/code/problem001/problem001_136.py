# -*- coding: utf-8 -*-

i = 1
while (i <= 9) :
    j = 1
    while (j <= 9) :
        print '%sx%s=%s' % (i, j, i * j)
        j = j + 1
    i = i + 1