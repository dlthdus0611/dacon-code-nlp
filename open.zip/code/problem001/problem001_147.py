i=[1,2,3,4,5,6,7,8,9]
j=[1,2,3,4,5,6,7,8,9]
for i1 in i:
    for j1 in j:
        answer=i1*j1
        print(str(i1)+"x"+str(j1)+"="+str(answer))
