r=range(1,10)
[print('%dx%d=%d'%(i,j,i*j))for i in r for j in r]
