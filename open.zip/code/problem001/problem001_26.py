i=1
while i<10:
    j=1
    while j<10:
        print('{}x{}={}'.format(i,j,i*j))
        j+=1
    i+=1
