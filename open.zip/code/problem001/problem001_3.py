for i in range(1, 10):

	for ii in range(1, 10):

		print('{}x{}={}'.format(i, ii, i*ii))