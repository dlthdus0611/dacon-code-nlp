if __name__ == "__main__":

    for num1 in range(0, 9):
        for num2 in range(0, 9):
            print(str(num1 + 1) + "x" + str(num2 + 1) + "=" + str((num1 + 1) * (num2 + 1)))