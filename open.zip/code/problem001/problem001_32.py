for i in range(1, 10):
    for j in range(1, 10):
          print (u"%dx%d=%d"%(i,j,i*j))