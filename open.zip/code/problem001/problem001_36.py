def kakeru(x):
    for i in range(1,10):
        a = x * i
        print(str(x) + 'x' +str(i) + '=' + str(a))

for i in range (1,10):
    kakeru(i)