[[print("{}x{}={}".format(i,j,i*j))for j in range(1,10)]for i in range(1,10)]
