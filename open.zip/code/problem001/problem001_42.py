
for i in range(1,10):
    for j in range(1,10):
	print "%d%s%d%s%d" % (i,"x",j,"=",i*j)