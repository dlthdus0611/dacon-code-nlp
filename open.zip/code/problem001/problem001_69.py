for x in range(1,10):
    for y in range(1,10):
        print str(x)+"x"+str(y)+"="+str(x*y)