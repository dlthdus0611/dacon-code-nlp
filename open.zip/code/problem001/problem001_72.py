for ii in range(1,10):
    for jj in range(1,10):
        print("{}x{}={}".format(ii,jj,ii*jj))