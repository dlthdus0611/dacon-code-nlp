mt = []

for i in range(10):
        mt.append(int(input()))

mt.sort()
print( mt[9] )
print( mt[8] )
print( mt[7] )