j = []
for i in range(10) :
    j.append(int(input()))
j.sort(reverse = True)
for k in range(3) :
    print(j[k])