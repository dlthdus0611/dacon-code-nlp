list = []
for i in  range(10):
    a = input()
    list.append(a)
list = sorted(list)
for i in range(-1, -4, -1):
    print(list[i])