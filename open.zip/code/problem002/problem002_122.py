m = []
for _ in range(10):
    r = int(input())
    m.append(r)

m.sort()

print (m[9]);
print (m[8]);
print (m[7]);