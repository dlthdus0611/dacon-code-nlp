a=[int(input()) for i in range(10)]
a.sort()
a.reverse()
print(a[0])
print(a[1])
print(a[2])