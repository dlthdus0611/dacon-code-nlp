data = []
for i in range(10):
    data.append(int(input()))
data = sorted(data)
print(data[-1])
print(data[-2])
print(data[-3])