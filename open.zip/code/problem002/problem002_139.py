#!/usr/bin/env python
# -*- coding: utf-8 -*-

h = [int(input()) for i in range(10)]
h.sort()
h.reverse()

print(h[0])
print(h[1])
print(h[2])