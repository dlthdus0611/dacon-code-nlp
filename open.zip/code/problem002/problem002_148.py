for i in sorted([int(input()) for _ in range(10)], reverse=True)[:3]:
    print(i)