s = [int(input()) for i in range(10)]
s.sort(reverse = True)
for i in s[:3]:
    print(i)
