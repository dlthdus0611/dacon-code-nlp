hs=[int(input()) for i in range(10)]
h=sorted(hs,reverse=True)
for i in range(3):
  print(h[i])
