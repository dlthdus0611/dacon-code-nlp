mountains = [int(input()) for i in range(10)]
for i in sorted(mountains)[7:10][::-1]:
    print(i)