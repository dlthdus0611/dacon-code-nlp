# -*- coding: UTF-8 -*-

lst = [int(raw_input()) for i in range(10)]
lst.sort()
lst.reverse()

print lst[0]
print lst[1]
print lst[2]