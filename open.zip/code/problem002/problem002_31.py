heights = []

for _ in range(10):
	heights.append(int(input()))

heights.sort()
print(heights[9])
print(heights[8])
print(heights[7])