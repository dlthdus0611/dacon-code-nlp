A = [int(input()) for i in range(10)]
for i in sorted(A)[:-4:-1]:
    print(i)
