spam = [int(input()) for i in range(0, 10)]
spam.sort()
spam.reverse()
for i in range(0,3):
    print(spam[i])