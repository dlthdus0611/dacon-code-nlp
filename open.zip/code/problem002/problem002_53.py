mounts =[int(input()) for i in range(10)]
mounts.sort(reverse = True)
for i in range(3):
  print(mounts[i])