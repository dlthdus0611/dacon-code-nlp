n = 0
list = []
while n < 10:
    x = int(input())
    list.append(x)
    n += 1

list.sort()
print(list[9])
print(list[8])
print(list[7])