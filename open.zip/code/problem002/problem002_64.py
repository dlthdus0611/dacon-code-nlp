mountain = [int(input()) for _ in range(10)]
mountain.sort()
for _ in -1, -2, -3 : print(mountain[_])