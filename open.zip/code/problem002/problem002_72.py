mh=[]

for i in range(1,11):
    mh.append(int(input()))

mh.sort(reverse=True)
print(mh[0])
print(mh[1])
print(mh[2])


