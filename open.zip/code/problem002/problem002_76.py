h=[]
for i in range(10):
    h.append((int)(input()))
h.sort()
h.reverse()
for i in range(3):
    print(h[i])

