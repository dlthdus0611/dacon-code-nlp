a = [];
for i in range(0, 10):
	a.append(int(input()));
	
a.sort(reverse = True);
for i in range(0, 3):
	print(a[i]);