m=[]
for i in range(10):
    x = input()
    m.append(x)
m.sort()
m.reverse()
for i in range(0,3):
    print m[i]
 