# coding: utf-8
# Here your code !
ret = []
for i in range(10):
    ret.append(int(input()))

ret.sort()

print(ret[-1])
print(ret[-2])
print(ret[-3])