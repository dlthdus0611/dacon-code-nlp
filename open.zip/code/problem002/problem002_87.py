hills = [input() for x in xrange(10)]
hills.sort(reverse=True)
for x in xrange(3):
	print hills[x]