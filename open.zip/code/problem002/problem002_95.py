i = 0
x = []
for i in range(10):
    mount = int(input())
    x.append(mount)
sorted_x = sorted(x)
print(sorted_x[-1])
print(sorted_x[-2])
print(sorted_x[-3])

