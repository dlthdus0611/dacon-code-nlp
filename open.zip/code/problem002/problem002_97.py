arr = list([input() for _ in range(10)])
  
arr.sort(reverse=True)
 
for i in range(3):
    print arr[i]
