while True:
    try:
        print(len(str(sum(list(map(int, input().split()))))))
    except:
        break
