while 1:
    try:
        print(len(str(sum(map(int,input().split())))))
    except: break