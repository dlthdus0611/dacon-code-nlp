for i in range(200):
    
    try:
        a,b=map(int,input().split())
        print(len(str(a+b)))
    except:
        pass
